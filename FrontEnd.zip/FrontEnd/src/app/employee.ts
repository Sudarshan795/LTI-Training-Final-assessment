export class Employee {
    id?: any;
    firstName?: string;
    lastName?: string;
    emailId?: string;
}
