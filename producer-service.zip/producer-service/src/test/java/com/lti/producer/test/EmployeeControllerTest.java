package com.lti.producer.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Assert;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.lti.producer.controller.EmployeeController;
import com.lti.producer.entity.Employee;
import com.lti.producer.repository.EmployeeRepository;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import org.junit.runner.RunWith;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EmployeeControllerTest {

	@MockBean
	private EmployeeRepository employeeRepository;

	@Autowired
	private EmployeeController employeeController;

	@Test
	public void testCreateEmployee() {
		Employee employee = new Employee();
		employee.setFirstName("firstname");
		employee.setLastName("lastname");
		employee.setEmailId("test@gmail.com");

		Mockito.when(employeeRepository.save(employee)).thenReturn(employee);

		assertThat(employeeController.createEmployee(employee)).isEqualTo(employee);
	}

	@Test
	public void testGetEmployeeById() throws Exception {
		Employee employee = new Employee();
		employee.setId(1L);
		employee.setFirstName("sudarshan");
		employee.setLastName("rao");
		employee.setEmailId("sr123@gmail.com");
	}

	

    @Test
    public void testGetAllPresentEmployees() throws Exception{
    	Employee employee1 = new Employee();
		employee1.setId(15L);
		employee1.setFirstName("sudarshan");
		employee1.setLastName("rao");
		employee1.setEmailId("sr123@gmail.com");

		Employee employee2 = new Employee();
		employee2.setId(15L);
		employee2.setFirstName("ruchir");
		employee2.setLastName("rahang");
		employee2.setEmailId("rr@gmail.com");

        List<Employee> empList = new ArrayList<>();
        empList.add(employee1);
        empList.add(employee2);

    }
    
    
    

    @Test
    public void testDeleteEmployeeById() throws Exception{
    	Employee employee2 = new Employee();
		employee2.setId(15L);
		employee2.setFirstName("ruchir");
		employee2.setLastName("rahang");
		employee2.setEmailId("rr@gmail.com");

    }
    
    @Test
    public void testUpdateEmployee() throws Exception{
     	Employee employee2 = new Employee();
    		employee2.setId(15L);
    		employee2.setFirstName("ruchir");
    		employee2.setLastName("rahang");
    		employee2.setEmailId("rr@gmail.com");
    		employeeRepository.save(employee2);
    }
}
