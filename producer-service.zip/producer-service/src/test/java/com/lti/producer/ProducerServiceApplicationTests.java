package com.lti.producer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
